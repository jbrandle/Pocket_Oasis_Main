
import { GoogleGenAI, Type, Modality, ThinkingLevel } from "@google/genai";
import { ZoneType, AdventureMessage, CharacterStats, SubSystemType, AdventureRewards, AICompanion } from "../types";

// Using Flash for speed/cost effectiveness on mobile
const MODEL_TEXT = "gemini-3-flash-preview";
const MODEL_TTS = "gemini-2.5-flash-preview-tts";
const API_TIMEOUT_MS = 15000; // 15 seconds timeout

export interface AdventureResponse {
  narrative: string;
  integrityChange: number; // negative for damage, positive for healing
  status: 'PLAYING' | 'WON' | 'LOST';
  summary: string; // Updated context summary
  rewards: AdventureRewards;
  missionBriefing?: string; // Only for start
  mapHUD?: string; // Current location/coordinates
  companionSuggestion?: string; // Advice from the AI companion
}

const timeoutPromise = (ms: number) => new Promise<never>((_, reject) => setTimeout(() => reject(new Error("Request timed out")), ms));

// Audio State Management
let audioContext: AudioContext | null = null;
let currentAudioSource: AudioBufferSourceNode | null = null;

const getAudioContext = () => {
    if (!audioContext) {
        audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    }
    return audioContext;
};

// Base64 decoding
function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

// Raw PCM Decoding
async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export const stopSpeech = () => {
    if (currentAudioSource) {
        try {
            currentAudioSource.stop();
        } catch (e) {
            // ignore
        }
        currentAudioSource = null;
    }
};

// Fix: Create GoogleGenAI instance inside the function as per guidelines
export const generateSpeech = async (text: string): Promise<void> => {
    stopSpeech(); // Stop any currently playing audio

    // Strip markdown asterisks for cleaner speech
    const cleanText = text.replace(/\*/g, '').replace(/_/g, '');

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
            model: MODEL_TTS,
            contents: [{ parts: [{ text: cleanText }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                        // 'Charon' is deep and mythic, good for DM
                        prebuiltVoiceConfig: { voiceName: 'Charon' },
                    },
                },
            },
        });

        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (!base64Audio) return;

        const ctx = getAudioContext();
        if (ctx.state === 'suspended') {
            await ctx.resume();
        }

        const audioBytes = decode(base64Audio);
        const audioBuffer = await decodeAudioData(audioBytes, ctx, 24000, 1);

        const source = ctx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(ctx.destination);
        source.start();
        currentAudioSource = source;

        return new Promise((resolve) => {
            source.onended = () => {
                currentAudioSource = null;
                resolve();
            };
        });

    } catch (error) {
        console.error("Speech generation failed", error);
        throw error;
    }
};

// Fix: Create GoogleGenAI instance inside the function as per guidelines
export const startAdventure = async (zone: ZoneType, playerLevel: number, stats?: CharacterStats, subSystem?: SubSystemType, companion?: AICompanion): Promise<AdventureResponse> => {
  const statsText = stats 
    ? `Neural Processing(INT):${stats.neuralProcessing}, Synaptic Speed(DEX):${stats.synapticSpeed}, System Integrity(CON):${stats.systemIntegrity}, Digital Presence(CHA):${stats.digitalPresence}`
    : "Standard stats";
    
  const classText = subSystem || "OPERATOR";
  const companionText = companion ? `${companion.name} (${companion.personality})` : "Basic OS";
  const randomSeed = Date.now().toString() + Math.random().toString();

  const prompt = `
    You are the Neural Architect for a high-stakes, cinematic, and immersive text adventure in the "${zone}" zone of the OASIS metaverse.
    You manage the Narrative Engine. Your tone should be DARK, DRAMATIC, and INTENSE.
    Player Level: ${playerLevel}.
    Player Class (Subsystem): ${classText}.
    Player Stats: ${statsText}.
    AI Companion: ${companionText}.
    Random Seed: ${randomSeed}.

    Task:
    Generate a UNIQUE and RANDOMIZED initial scenario for the player.
    1. MISSION BRIEFING: Start with a "background" (the lore/reason for being here) and then a clear "mission" (the objective).
    2. Set the scene vividly. Do NOT repeat common start scenarios.
    3. MAP HUD: Provide a current location name or coordinates (e.g., "Sector 7-G, Neon Slums").
    4. COMPANION SUGGESTION: Provide a short piece of advice from the AI companion ${companionText} based on their personality.
    5. Present a clear but open-ended objective.

    Return JSON format:
    {
      "missionBriefing": "Background: ... Mission: ...",
      "narrative": "The full descriptive text of the opening scene...",
      "integrityChange": 0,
      "status": "PLAYING",
      "summary": "Brief summary of the start",
      "mapHUD": "Location Name",
      "companionSuggestion": "Advice from companion...",
      "rewards": { "xp": 0, "credits": 0, "items": [] }
    }
  `;

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const apiCall = ai.models.generateContent({
      model: MODEL_TEXT,
      contents: prompt,
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        temperature: 1.0, // High temperature for maximum variety
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            missionBriefing: { type: Type.STRING },
            narrative: { type: Type.STRING },
            integrityChange: { type: Type.INTEGER },
            status: { type: Type.STRING, enum: ["PLAYING", "WON", "LOST"] },
            summary: { type: Type.STRING },
            mapHUD: { type: Type.STRING },
            companionSuggestion: { type: Type.STRING },
            rewards: {
              type: Type.OBJECT,
              properties: {
                xp: { type: Type.INTEGER },
                credits: { type: Type.INTEGER },
                items: { type: Type.ARRAY, items: { type: Type.STRING } }
              }
            }
          },
          required: ["narrative", "integrityChange", "status", "summary", "rewards", "missionBriefing", "mapHUD", "companionSuggestion"]
        }
      }
    });

    const response = await Promise.race([apiCall, timeoutPromise(API_TIMEOUT_MS)]);
    // Fix: access response.text property directly, not as a method
    const data = JSON.parse((response as any).text || "{}");
    
    // Validate essential fields
    if (!data.narrative) throw new Error("Invalid response format");
    if (!data.rewards) data.rewards = { xp: 0, credits: 0, items: [] };

    return data;
  } catch (error) {
    console.error("Adventure Init Error:", error);
    return {
      narrative: "Connection unstable. The simulation could not initialize. Try again.",
      integrityChange: 0,
      status: "PLAYING",
      summary: "Error",
      rewards: { xp: 0, credits: 0, items: [] }
    };
  }
};

// Fix: Create GoogleGenAI instance inside the function as per guidelines
export const continueAdventure = async (
  zone: ZoneType, 
  history: AdventureMessage[], 
  currentSummary: string, 
  playerInput: string,
  stats?: CharacterStats,
  subSystem?: SubSystemType,
  companion?: AICompanion
): Promise<AdventureResponse> => {
  
  // Construct a focused prompt using the summary + last few turns to save tokens/context window
  const recentHistory = history.slice(-3).map(msg => `${msg.sender}: ${msg.text}`).join('\n');
  
  const statsText = stats 
    ? `Neural Processing(INT):${stats.neuralProcessing}, Synaptic Speed(DEX):${stats.synapticSpeed}, System Integrity(CON):${stats.systemIntegrity}, Digital Presence(CHA):${stats.digitalPresence}`
    : "Standard stats";
    
  const classText = subSystem || "OPERATOR";
  const companionText = companion ? `${companion.name} (${companion.personality})` : "Basic OS";

  const prompt = `
    Roleplay as the dramatic and intense Neural Architect for an adventure in ${zone}.
    Current Context: ${currentSummary}
    Player Class: ${classText}
    Player Stats: ${statsText}
    AI Companion: ${companionText}
    
    Recent Log:
    ${recentHistory}
    
    Player Action: "${playerInput}"

    RULES FOR MECHANICS:
    1. **Consequences**: Decisions MUST have consequences. If a player makes a reckless or stupid decision, they should take damage or fail.
    2. **Skill Checks**: Compare player action to their Stats.
    3. **XP Rewards**: ONLY reward XP (5-20) if the decision was SMART and SUCCESSFUL based on their stats. If they just got lucky or did something basic, 0 XP.
    4. **Map HUD**: Update the current location or coordinates based on the narrative.
    5. **Companion Suggestion**: Provide a short, personality-driven suggestion for the NEXT move from ${companionText}.

    Return JSON:
    {
      "narrative": "What happens next...",
      "integrityChange": number,
      "status": "PLAYING" | "WON" | "LOST",
      "summary": "Updated 1-sentence summary",
      "mapHUD": "Updated Location",
      "companionSuggestion": "Suggestion for next move...",
      "rewards": {
         "xp": number,
         "credits": number,
         "items": ["item1"]
      }
    }
  `;

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const apiCall = ai.models.generateContent({
      model: MODEL_TEXT,
      contents: prompt,
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            narrative: { type: Type.STRING },
            integrityChange: { type: Type.INTEGER },
            status: { type: Type.STRING, enum: ["PLAYING", "WON", "LOST"] },
            summary: { type: Type.STRING },
            mapHUD: { type: Type.STRING },
            companionSuggestion: { type: Type.STRING },
            rewards: {
              type: Type.OBJECT,
              properties: {
                xp: { type: Type.INTEGER },
                credits: { type: Type.INTEGER },
                items: { type: Type.ARRAY, items: { type: Type.STRING } }
              }
            }
          },
          required: ["narrative", "integrityChange", "status", "summary", "rewards", "mapHUD", "companionSuggestion"]
        }
      }
    });

    const response = await Promise.race([apiCall, timeoutPromise(API_TIMEOUT_MS)]);
    // Fix: access response.text property directly, not as a method
    const data = JSON.parse((response as any).text || "{}");
    
    // Safety check for rewards object
    if (!data.rewards) data.rewards = { xp: 0, credits: 0, items: [] };
    if (!data.status) data.status = 'PLAYING';
    
    return data;
  } catch (error) {
    console.error("Adventure Turn Error:", error);
    return {
      narrative: "The simulation glitched. Your command was lost in the datastream.",
      integrityChange: 0,
      status: "PLAYING",
      summary: currentSummary,
      rewards: { xp: 0, credits: 0, items: [] }
    };
  }
};
